from pathlib import Path
import json,hashlib,sys
r=Path(__file__).resolve().parents[3];fixture=r/'.godot/verification/e07_f1/fixture_project'
allowed=set(json.loads((r/'docs/epics/e08_p4_directional_files.json').read_text())['files'])
m=fixture/'source_hashes.json';data=json.loads(m.read_text(encoding='utf-8'));new=data.copy();changes=[]
out=r/'.godot/verification/p4_directional'/sys.argv[1]
out.mkdir(exist_ok=False,parents=True);(out/'before_source_hashes.json').write_bytes(m.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for rel,h in data.items():
 assert sha(fixture/rel)==h,('unexpected fixture delta',rel)
 if sha(r/rel)!=h:
  assert rel in allowed,('not owned',rel)
  prev=out/'previous'/rel;prev.parent.mkdir(parents=True,exist_ok=True);prev.write_bytes((fixture/rel).read_bytes())
  (fixture/rel).write_bytes((r/rel).read_bytes());new[rel]=sha(r/rel);changes.append({'path':rel,'before':h,'after':new[rel]})
for rel in sorted(allowed):
 p=r/rel
 if rel not in new and p.is_file() and rel.split('/')[0] in ['scripts','tools','tests'] and not rel.endswith('.import'):
  dest=fixture/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes());new[rel]=sha(p);changes.append({'path':rel,'before':None,'after':new[rel]})
m.write_text(json.dumps(new,indent=2,sort_keys=True)+'\n',encoding='utf-8');(out/'delta.json').write_text(json.dumps({'reason':sys.argv[2],'changes':changes},indent=2)+'\n')
print('Explicit owned source/fixture delta:',len(changes))
