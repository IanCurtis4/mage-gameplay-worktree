extends SceneTree

func _initialize() -> void:
	var nav := ArenaNavigation.new()
	nav.configure(RunController.ARENA_BOUNDS, RunController.ARENA_OBSTACLES, 22.0)
	var start := Vector2(300, 520)
	var destination := Vector2(500, 610)
	var path := nav.get_path(start, destination)
	var length := 0.0
	var previous := start
	for point in path:
		length += previous.distance_to(point)
		previous = point
	print("Clear direct segment: ", nav.is_segment_walkable(start, destination))
	print("Waypoints: ", path.size(), " path length: ", length, " direct distance: ", start.distance_to(destination))
	var state := RunState.new()
	var player := PlayerActor.new()
	player.configure(nav, state)
	player.global_position = Vector2(300, 520)
	for i in range(3):
		player.slash_cooldown = 0.0
		print("Slash ", i + 1, " accepted: ", player.use_slash(Vector2.RIGHT, []), " mana: ", player.mana)
	player.slash_cooldown = 0.0
	print("Slash 4 accepted: ", player.use_slash(Vector2.RIGHT, []))
	for i in range(600):
		player._process(1.0 / 60.0)
	print("Mana after 10s alive: ", player.mana)
	player.free()
	quit()
