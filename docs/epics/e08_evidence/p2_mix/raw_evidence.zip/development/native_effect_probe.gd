extends SceneTree
func _initialize() -> void:
	var report := {"engine":Engine.get_version_info(), "classes":{}}
	for type: StringName in [&"AudioEffectHardLimiter", &"AudioEffectLimiter", &"AudioEffectCompressor", &"AudioEffectCapture"]:
		var entry := {"available":ClassDB.class_exists(type), "properties":[]}
		if entry.available:
			var effect: Object = ClassDB.instantiate(type)
			for property: Dictionary in effect.get_property_list():
				if property.usage & PROPERTY_USAGE_STORAGE:
					entry.properties.append({"name":property.name,"default":str(effect.get(property.name)),"hint":property.hint_string})
		report.classes[type] = entry
	var file := FileAccess.open(OS.get_cmdline_user_args()[0],FileAccess.WRITE)
	file.store_string(JSON.stringify(report,"  ",true));file.close()
	print(JSON.stringify(report))
	quit()
