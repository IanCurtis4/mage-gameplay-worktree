extends SceneTree
func _initialize() -> void:
	var main_scene: String = ProjectSettings.get_setting("application/run/main_scene", "")
	var app_name: String = ProjectSettings.get_setting("application/config/name", "")
	var result := {"main_scene": main_scene, "app_name": app_name, "user_data_dir": OS.get_user_data_dir(), "character_menu": ResourceLoader.exists("res://scenes/character_menu.tscn"), "forest_phase": FileAccess.file_exists("res://data/expedition/phases/forest_sanctuary.json"), "registry": FileAccess.file_exists("res://data/map_authoring/release_packages.json"), "preparation_manifest": FileAccess.file_exists("res://scripts/core/expedition/snapshot/runtime_manifest.json")}
	var ok := main_scene == "res://scenes/character_menu.tscn" and app_name == "RagRPG E08 Piloto1" and OS.get_user_data_dir().ends_with("RagRPG E08 Piloto1")
	for key: String in ["character_menu", "forest_phase", "registry", "preparation_manifest"]:
		ok = ok and bool(result[key])
	var sound_count := 0
	for id: StringName in AudioEventCatalog.ids():
		var definition: Dictionary = AudioEventCatalog.definition(id)
		var sound := load(str(definition.get("path", ""))) as AudioStreamWAV
		if sound != null and sound.get_length() > 0.0: sound_count += 1
	var body_count := 0
	for path: String in ["res://assets/art/animations/e08_forest_wolf.png", "res://assets/art/animations/e08_forest_boar.png"]:
		var body := load(path) as Texture2D
		if body != null and body.get_size() == Vector2(256,512): body_count += 1
	result["sounds"] = sound_count
	result["body_atlases"] = body_count
	result["release_binary"] = not OS.has_feature("editor")
	ok = ok and sound_count == 12 and body_count == 2 and ClassDB.class_exists("AudioEffectHardLimiter")
	result["ok"] = ok
	print("E08_PACK_INSPECTION ", JSON.stringify(result))
	quit(0 if ok else 1)