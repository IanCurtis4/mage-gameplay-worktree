extends SceneTree
const V1 = preload("res://tests/fixtures/e08_directional/fixture.gd")

var checks := 0
var failures := 0

func _initialize() -> void:
	var state := CombatAnimationState.new()
	_check(state.frame_index() == 0, "idle starts on the frontal atlas row")
	state.advance(0.25, Vector2.ZERO)
	_check(state.frame_index() == 1, "idle advances without changing the actor position")
	state.advance(0.1, Vector2(-22, -22))
	_check(state.back_view and state.flip_h and state.frame_index() in range(12, 16), "walking northwest selects the mirrored rear walk")
	state.trigger(&"cast", Vector2.RIGHT, 0.4)
	state.advance(0.1, Vector2(-10, -10))
	_check(not state.back_view and not state.flip_h and state.frame_index() == 9, "movement cannot rotate an active cast presentation")
	state.advance(0.4, Vector2(-10, -10))
	_check(state.back_view and state.flip_h and state.frame_index() in range(12, 16), "locomotion resumes after an action without a gameplay lock")
	state.trigger(&"hurt")
	_check(state.frame_index() == 26, "rear flinch uses the rear hurt frames")
	state.trigger(&"death")
	state.trigger(&"cast", Vector2.RIGHT)
	state.advance(0.3, Vector2(30, 0))
	_check(state.frame_index() == 31 and state.dead, "death overrides hurt and rejects later actions")
	var preparation := CombatAnimationState.new()
	preparation.trigger(&"cast", Vector2.RIGHT, 0.8)
	preparation.advance(0.5, Vector2.ZERO)
	_check(preparation.action_remaining > 0.0, "cast presentation respects the complete gameplay preparation duration")
	preparation.trigger(&"cast_cancel")
	_check(preparation.action_remaining == 0.0, "cancelling gameplay preparation clears its visual action")
	for fps: int in [30, 60, 144]:
		var paced := CombatAnimationState.new()
		for index: int in range(fps):
			paced.advance(1.0 / fps, Vector2(220.0 / fps, 0))
		_check(paced.frame_index() == 5, "walk phase follows compact stride consistently at %d Hz" % fps)
	for id: StringName in [&"swordsman", &"mage", &"warrior", &"archer", &"defender", &"berserker"]:
		var animation := V1.legacy_animation(id)
		_check(animation.atlas != null and animation.atlas.get_size() == Vector2(256, 512), "%s contains 32 native 64 px animation frames" % id)
		if animation.atlas == null:
			continue
		var bitmap := animation.atlas.get_image()
		var frames_valid := true
		for index: int in range(32):
			var region := Rect2i(Vector2i(index % 4 * 64, index / 4 * 64), Vector2i(64, 64))
			var frame := bitmap.get_region(region)
			var used := frame.get_used_rect()
			frames_valid = frames_valid and used.has_area() and used.end.y <= 59 and frame.get_pixel(0, 0).a == 0.0
		_check(frames_valid, "%s has nonempty aligned frames and genuine alpha gutters" % id)
		var clone := animation.death_copy()
		_check(clone.atlas == animation.atlas and clone.state != animation.state and not animation.state.dead, "%s death copy shares immutable art but no runtime state" % id)
	_test_integration.call_deferred()

func _test_integration() -> void:
	var navigation := ArenaNavigation.new()
	navigation.configure(Rect2(0, 0, 1000, 700), [], 20.0)
	var base_snapshot := BuildSnapshot.new()
	base_snapshot.base_class_id = &"swordsman"
	var base_player := PlayerActor.new()
	base_player.configure(navigation, RunState.from_build("base-visual", base_snapshot))
	_check(base_player.character_animation.actor_kind == &"swordsman", "base Swordsman keeps its original atlas")
	var defender_snapshot := BuildSnapshot.new()
	defender_snapshot.base_class_id = &"swordsman"
	defender_snapshot.evolution_id = &"defender"
	var defender_player := PlayerActor.new()
	defender_player.configure(navigation, RunState.from_build("defender-visual", defender_snapshot))
	_check(defender_player.class_id == &"swordsman" and defender_player.character_animation.actor_kind == &"defender" and defender_player.character_animation.atlas != base_player.character_animation.atlas, "Defender changes only the visual atlas, preserving base gameplay identity")
	var berserker_snapshot := BuildSnapshot.new()
	berserker_snapshot.base_class_id = &"swordsman"
	berserker_snapshot.evolution_id = &"berserker"
	var berserker_player := PlayerActor.new()
	berserker_player.configure(navigation, RunState.from_build("berserker-visual", berserker_snapshot))
	_check(berserker_player.class_id == &"swordsman" and berserker_player.character_animation.actor_kind == &"berserker" and berserker_player.character_animation.atlas != base_player.character_animation.atlas and berserker_player.character_animation.atlas != defender_player.character_animation.atlas, "Berserker has a distinct 32-frame atlas without changing Swordsman gameplay identity")
	base_player.free()
	defender_player.free()
	berserker_player.free()
	RunController.selected_class_id = &"mage"
	var controller := RunController.new()
	root.add_child(controller)
	await process_frame
	var player := controller.player
	_check(player.character_animation.actor_kind == &"mage", "selected class uses its own integrated atlas")
	player.presentation_action.emit(&"cast", Vector2.LEFT, 0.3)
	_check(player.character_animation.state.flip_h, "gameplay presentation signal reaches the animator")
	var phase := player.character_animation.state.action_remaining
	paused = true
	player._process(0.1)
	_check(is_equal_approx(player.character_animation.state.action_remaining, phase), "paused actors preserve animation phase")
	paused = false
	var enemy := controller.enemies[0]
	var initial_count := controller.enemies.size()
	var damage := DamageRequest.new()
	damage.physical_damage = 100000.0
	damage.accuracy_mode = DamageRequest.AccuracyMode.GEOMETRY
	damage.can_crit = false
	damage.target_id = enemy.get_instance_id()
	enemy.apply_damage(damage, controller.rng)
	_check(controller.enemies.size() == initial_count - 1 and enemy.is_queued_for_deletion(), "death presentation never delays authoritative enemy removal")
	var ghosts := 0
	for child: Node in controller.get_children():
		if child is ActorDeathVisual:
			ghosts += 1
	_check(ghosts == 1, "elimination creates exactly one noninteractive death copy")
	damage.target_id = player.get_instance_id()
	player.apply_damage(damage, controller.rng)
	_check(controller.run_finished and paused and not player.visible, "player death ends the run immediately and hides the live sprite")
	paused = false
	controller.queue_free()
	await process_frame
	RunController.selected_class_id = &"swordsman"
	print("Animações: %s (%d checks)" % ["PASS" if failures == 0 else "FAIL", checks])
	quit(0 if failures == 0 else 1)

func _check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(label)
