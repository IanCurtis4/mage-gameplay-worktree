extends SceneTree
## Temporary review probe: lateral idle/action grips for the 10 player bodies.
## Args: <output.png> [manifest_root]  (manifest_root/<kind>/presentation.json)
const D = preload("res://tests/fixtures/e08_directional/fixture.gd")
const KINDS: Array[StringName] = [&"swordsman",&"mage",&"archer",&"defender",&"berserker",&"elementalist",&"spiritualist",&"sentinel",&"hunter",&"geometer"]
const GEAR := {&"swordsman":{"main_hand":&"sword","off_hand":&"shield"},&"defender":{"main_hand":&"sword","off_hand":&"shield"},
	&"berserker":{"main_hand":&"axe"},&"archer":{"main_hand":&"bow"},&"sentinel":{"main_hand":&"bow"},&"hunter":{"main_hand":&"bow"},
	&"mage":{"main_hand":&"staff"},&"elementalist":{"main_hand":&"staff"},&"spiritualist":{"main_hand":&"staff"},&"geometer":{"main_hand":&"staff"}}
const COLUMNS := [[2,0],[2,8],[2,9],[2,10],[2,12],[3,0],[3,8],[3,9],[3,10],[3,12]]
const SCALE := 3
class Layer extends Node2D:
	var animation: CharacterAnimation
	func _draw() -> void: animation.draw_on(self,Color.WHITE,float(3))
func _initialize() -> void: run.call_deferred()
func run() -> void:
	var args := OS.get_cmdline_user_args()
	var output: String = args[0]
	var root_dir: String = args[1] if args.size()>1 else ""
	var cell := 64*SCALE
	var viewport := SubViewport.new();viewport.size=Vector2i(cell,cell);viewport.transparent_bg=true
	viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS;root.add_child(viewport)
	var sheet := Image.create(cell*COLUMNS.size(),cell*KINDS.size(),false,Image.FORMAT_RGBA8)
	sheet.fill(Color(0.12,0.16,0.2))
	var layer := Layer.new();layer.texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST;viewport.add_child(layer)
	for row: int in KINDS.size():
		var kind := KINDS[row]
		var animation := CharacterAnimation.new();animation.configure(kind)
		var path := DirectionalAnimationSet.default_path(kind) if root_dir.is_empty() else root_dir.path_join(String(kind)).path_join("presentation.json")
		var loaded := animation.set_directional_manifest(path)
		if not loaded.ok:push_error("manifest "+path+" "+str(loaded));continue
		animation.set_equipment_visual(GEAR[kind])
		layer.animation=animation
		for column: int in COLUMNS.size():
			animation.state=D.state(COLUMNS[column][0],COLUMNS[column][1])
			layer.position=Vector2(cell*0.5,cell*0.9)
			layer.queue_redraw()
			await process_frame;await process_frame;await RenderingServer.frame_post_draw
			var image := viewport.get_texture().get_image();image.convert(Image.FORMAT_RGBA8)
			sheet.blend_rect(image,Rect2i(0,0,cell,cell),Vector2i(column*cell,row*cell))
	sheet.save_png(output)
	print("lateral probe saved ",output)
	quit()
