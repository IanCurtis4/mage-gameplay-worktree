extends SceneTree
## Same script runs against the accepted E08 PCK and the new source. No V2 types.
class CrowdActor extends Node2D:
	var animation: CharacterAnimation
	func _init() -> void:texture_filter=CanvasItem.TEXTURE_FILTER_NEAREST
	func _draw() -> void:animation.draw_on(self)
var folder := ""
var mode := "legacy"
var actors: Array[CrowdActor] = []
func _initialize() -> void:run.call_deferred()
func frames(count: int) -> void:
	for i: int in count:await process_frame
func quantile(values: Array[float],fraction: float) -> float:
	var sorted := values.duplicate();sorted.sort();return sorted[mini(sorted.size()-1,int(floor((sorted.size()-1)*fraction)))]
func run() -> void:
	folder=OS.get_cmdline_user_args()[0];mode=OS.get_cmdline_user_args()[1]
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED);root.size=Vector2i(1280,720)
	var before := Performance.get_monitor(Performance.MEMORY_STATIC)
	for i: int in 96:
		var actor := CrowdActor.new();actor.animation=CharacterAnimation.new();actor.animation.configure(&"warrior" if mode.begins_with("unarmed_") else &"mage")
		if not mode.begins_with("unarmed_"):actor.animation.set_equipment_visual({"main_hand":&"staff","off_hand":&"shield","arms":&"wooden_beads"})
		if mode in ["directional","unarmed_directional"]:
			var result: Dictionary = actor.animation.call("set_directional_manifest","res://tests/fixtures/e08_directional/enemy/presentation.json" if mode=="unarmed_directional" else "res://tests/fixtures/e08_directional/presentation.json")
			if not result.get("ok",false):push_error(str(result));quit(1);return
		actor.position=Vector2(45+(i%16)*78,100+(i/16)*100);root.add_child(actor);actors.append(actor)
	await frames(90)
	var windows: Array[Dictionary] = []
	for moving: bool in [true,false]:
		for window: int in 3:
			var samples: Array[float] = [];var began := Time.get_ticks_usec();var previous := began
			while Time.get_ticks_usec()-began<3000000:
				await process_frame
				var now := Time.get_ticks_usec();var elapsed := (now-previous)/1000000.0;samples.append((now-previous)/1000.0);previous=now
				for actor: CrowdActor in actors:
					actor.animation.state.advance(elapsed,Vector2.RIGHT*80.0*elapsed if moving else Vector2.ZERO);actor.queue_redraw()
			windows.append({"moving":moving,"window":window,"samples_ms":samples,"median_ms":quantile(samples,0.5),"p95_ms":quantile(samples,0.95),"max_ms":samples.max()})
	var loaded := Performance.get_monitor(Performance.MEMORY_STATIC)
	for actor: CrowdActor in actors:actor.free()
	actors.clear();await frames(90)
	var result := {"mode":mode,"actor_count":96,"window_seconds":3,"windows":windows,"static_before":before,"static_loaded":loaded,"static_after_clear":Performance.get_monitor(Performance.MEMORY_STATIC),"device":RenderingServer.get_video_adapter_name(),"synthetic":mode in ["directional","unarmed_directional"],"scope":"forced-redraw renderer harness, including idle; no gameplay/campaign FPS certification"}
	var file := FileAccess.open(folder.path_join("result.json"),FileAccess.WRITE);file.store_string(JSON.stringify(result,"  ",true));file.close()
	print("E08 directional cost: ",mode," windows=",windows.size());quit()
