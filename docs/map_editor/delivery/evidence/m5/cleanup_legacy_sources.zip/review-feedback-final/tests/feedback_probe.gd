extends SceneTree

var failures := 0
var checks := 0

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	var nav := ArenaNavigation.new()
	nav.configure(RunController.ARENA_BOUNDS, RunController.ARENA_OBSTACLES, 22.0)
	var start := Vector2(300, 520)
	var destination := Vector2(500, 610)
	var path := nav.get_path(start, destination)
	var length := 0.0
	var previous := start
	for point in path:
		length += previous.distance_to(point)
		previous = point
	print("Open path: ", path.size(), " waypoints, length ", length, " vs ", start.distance_to(destination))
	_check(path.size() == 1 and absf(length - start.distance_to(destination)) < 0.01, "open path uses direct destination")
	for rate in [30, 60, 144]:
		var actor := PlayerActor.new()
		actor.configure(nav, RunState.new())
		root.add_child(actor)
		actor.set_process(false)
		actor.global_position = Vector2(300, 480)
		actor.move_to(Vector2(1500, 480))
		for i in range(rate):
			actor._process(1.0 / float(rate))
		print("Rate ", rate, " final ", actor.global_position)
		_check(actor.global_position.distance_to(Vector2(520, 480)) < 0.02, "one second has consistent displacement at %d Hz" % rate)
		actor.free()
	var detour_positions: Array[Vector2] = []
	for rate in [1, 60]:
		var actor := PlayerActor.new()
		actor.configure(nav, RunState.new())
		root.add_child(actor)
		actor.set_process(false)
		actor.global_position = Vector2(500, 300)
		actor.move_to(Vector2(900, 350))
		for i in range(rate * 2):
			actor._process(1.0 / float(rate))
		detour_positions.append(actor.global_position)
		actor.free()
	_check(detour_positions[0].distance_to(detour_positions[1]) < 0.1, "distance budget is consistent across obstacle waypoints")
	var player := PlayerActor.new()
	player.configure(nav, RunState.new())
	root.add_child(player)
	player.set_process(false)
	player.global_position = Vector2(300, 480)
	player.mana = 0
	for i in range(150):
		player._process(1.0 / 60.0)
	_check(player.mana >= 14.99, "empty mana regenerates enough for slash in 2.5 seconds")
	for i in range(60):
		player._process(1.0 / 60.0)
	_check(player.use_slash(Vector2.RIGHT, []), "slash can be reused after recovering mana")
	var target := CombatActor.new()
	target.setup("Probe", Color.WHITE, RpgStats.derive({"vit": 1}), 19.0)
	root.add_child(target)
	target.set_process(false)
	target.global_position = Vector2(550, 480)
	var attacks := [0]
	player.attack_requested.connect(func(_request: DamageRequest, _target: CombatActor) -> void: attacks[0] += 1)
	player.pursue(target)
	var backward_steps := 0
	for i in range(240):
		target.global_position.x += 1.0
		var before := player.global_position
		player._process(1.0 / 60.0)
		if player.global_position.x < before.x - 0.01:
			backward_steps += 1
	print("Moving pursuit: attacks ", attacks[0], ", backward steps ", backward_steps)
	_check(backward_steps == 0 and attacks[0] > 0, "moving pursuit attacks without backtracking")
	player.move_to(Vector2(300, 480))
	_check(player.target == null, "ground click cancels selected target")
	player.mana = 0.0
	player.set_process(true)
	paused = true
	for i in range(3):
		await process_frame
	_check(player.mana == 0.0, "real tree pause freezes mana regeneration")
	paused = false
	for i in range(3):
		await process_frame
	_check(player.mana > 0.0, "real tree resume regenerates mana")
	target.free()
	player.free()
	print("Independent feedback checks: ", checks, " failed: ", failures)
	quit(0 if failures == 0 else 1)

func _check(condition: bool, label: String) -> void:
	checks += 1
	if not condition:
		failures += 1
		push_error(label)
