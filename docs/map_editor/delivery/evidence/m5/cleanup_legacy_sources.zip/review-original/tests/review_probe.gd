extends SceneTree

func _initialize() -> void:
	_run.call_deferred()

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var controller := (load("res://scenes/main.tscn") as PackedScene).instantiate() as RunController
	root.add_child(controller)
	for i in range(4):
		await process_frame
	_dump(controller)
	for enemy: CombatActor in controller.enemies.duplicate():
		var request := DamageRequest.new()
		request.target_id = enemy.get_instance_id()
		request.base_damage = 99999
		enemy.apply_damage(request, controller.rng)
	controller.player.global_position = controller.reward.global_position
	await process_frame
	controller._open_augment_menu()
	for i in range(4):
		await process_frame
	_dump(controller)
	if DisplayServer.get_name() != "headless":
		await RenderingServer.frame_post_draw
		root.get_texture().get_image().save_png("res://../original-choice.png")
	paused = false
	controller.queue_free()
	quit()

func _dump(node: Node) -> void:
	if node is Control and node.visible:
		if node is Button or node is PanelContainer or node is Label:
			print(node.get_class(), " ", node.get_global_rect(), " ", node.text if node is Label or node is Button else "")
	for child in node.get_children():
		_dump(child)
