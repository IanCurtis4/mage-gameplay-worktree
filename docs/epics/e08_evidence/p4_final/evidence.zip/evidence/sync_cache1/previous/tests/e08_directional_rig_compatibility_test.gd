extends SceneTree
## Independent V1 API oracle for preserved S/N bodies, directional geometry for E/W.
const D = preload("res://tests/fixtures/e08_directional/fixture.gd")
const F = preload("res://tests/fixtures/e08_directional/content_fixture.gd")
const NATIVE: Array[StringName] = [&"swordsman",&"mage",&"archer",&"defender",&"berserker",&"hunter",&"sentinel",&"geometer"]
var checks := 0
var failures := 0
func _initialize() -> void: run.call_deferred()
func check(ok: bool,label: String) -> void:
	checks+=1
	if not ok: failures+=1;push_error(label)
func run() -> void:
	for kind: StringName in NATIVE:
		var loaded := DirectionalAnimationSet.load_manifest(F.stage_path(kind))
		check(loaded.ok,"native unit validates "+String(kind))
		if not loaded.ok:continue
		var old_body := load("res://assets/art/animations/%s_weaponless.png" % kind) as Texture2D
		var body: Image=loaded.bundle.body(true).get_image();var legacy: Image=old_body.get_image()
		for direction: int in 2:
			for pose: int in 14:
				var state := D.state(direction,pose)
				var frame: Dictionary=loaded.bundle.frame(direction*16+pose)
				var index := direction*16+pose;var old_index := state.frame_index()
				var a := body.get_region(Rect2i(index%4*64,index/4*64,64,64))
				var b := legacy.get_region(Rect2i(old_index%4*64,old_index/4*64,64,64))
				var same := true
				for y: int in 64:
					for x: int in 64:
						var pa := a.get_pixel(x,y);var pb := b.get_pixel(x,y)
						same=same and ((pa.a==0 and pb.a==0) or pa==pb)
				check(same,"all28 living native image cells preserved "+String(kind)+"/"+str(index))
				for slot: StringName in [&"main_hand",&"off_hand",&"arms"]:
					for key: StringName in EquipmentAttachmentVisual.SUPPORTED:
						var old := EquipmentAttachmentVisual.placement(kind,state,key,slot,Vector2.ZERO)
						var resolved := EquipmentAttachmentVisual.resolve_equipment(kind,state,{slot:key},Vector2.ZERO,frame)
						var now: Dictionary=resolved[0]
						var label := "%s/%d/%s/%s" % [kind,direction*16+pose,slot,key]
						check(now.point==old.point,label+" preserved anatomical native palm")
						check(now.finger_rect==old.finger_rect,label+" preserved native fingers")
						check(is_equal_approx(now.angle,old.angle),label+" independent V1 angle")
						check(now.depth==old.depth,label+" independent V1 occlusion")
						check(not now.flip,label+" native S/N local flip unchanged")
	for kind: StringName in F.ORIGINS:
		var animation := CharacterAnimation.new();animation.configure(kind)
		check(animation.set_directional_manifest(F.stage_path(kind)).ok,"explicit lateral unit")
		animation.set_equipment_visual({"main_hand":&"bow","head":&"pilot_head"})
		for direction: int in [2,3]:
			for pose: int in range(8,11):
				animation.state=D.state(direction,pose)
				var descriptor := animation.render_descriptor()
				var placed: Dictionary=descriptor.equipment[0]
				var transform := EquipmentAttachmentVisual.resolved_transform(placed,1.0,false)
				var arrow_delta := transform*Vector2(25,0)-transform*Vector2(-11,0)
				check(descriptor.arrow_visible,"launch phase has arrow")
				check(arrow_delta.x>10.0 if direction==2 else arrow_delta.x < -10.0,"arrow faces authored target, not opposite "+String(kind)+"/"+str(direction*16+pose))
	print("E08 directional rig compatibility: %d checks, %d failures" % [checks,failures])
	quit(1 if failures else 0)
