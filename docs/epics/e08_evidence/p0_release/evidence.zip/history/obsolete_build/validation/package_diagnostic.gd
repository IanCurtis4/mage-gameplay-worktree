extends SceneTree
const Assets = preload("res://scripts/map_authoring/assets/asset_manifest.gd")
const Store = preload("res://scripts/map_authoring/patrol/patrol_store.gd")
const Patrol = preload("res://scripts/map_authoring/patrol/patrol_compiler.gd")
const Population = preload("res://scripts/map_authoring/population/population_compiler.gd")
const Map = preload("res://scripts/map_authoring/composition/map_compiler.gd")
func _initialize() -> void:
 call_deferred("run")
func run() -> void:
 var p := "res://data/map_authoring/forest_terraces.d9d52701a7a4.rpp"
 var bytes := FileAccess.get_file_as_bytes(p)
 print("RAW ",bytes.size()," ",FileAccess.get_sha256(p))
 var decoded: Dictionary = bytes_to_var(bytes.slice(68))
 scan(decoded)
 print(FileAccess.get_file_as_string("res://assets/art/map_authoring/props/woodland_shrub.png.import"))


 print("MATERIALS ",preload("res://scripts/map_authoring/terrain/terrain_material.gd").dependencies())
 print("PROPS ",preload("res://scripts/map_authoring/objects/prop_catalog.gd").load_catalog().get("code"))
 quit()
func scan(v: Variant) -> void:
 if v is Dictionary:
  if v.has("path") and v.has("sha256"):
   var path := str(v.path)
   var actual := Assets.sha256(path)
   if actual != v.sha256: print("MISMATCH ",path," EXPECTED ",v.sha256," ACTUAL ",actual," MANIFEST ",Assets.sha256_for(path,true))
  for x: Variant in v.values(): scan(x)
 elif v is Array:
  for x: Variant in v: scan(x)
