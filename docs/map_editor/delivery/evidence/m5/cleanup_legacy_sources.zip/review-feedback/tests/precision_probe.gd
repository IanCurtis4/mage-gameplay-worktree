extends SceneTree

func _initialize() -> void:
	var position := Vector2(512, 480)
	var point := Vector2(1500, 480)
	var remaining_distance := 220.0 / 30.0
	for iteration in range(4):
		var distance := position.distance_to(point)
		var travel := minf(distance, remaining_distance)
		var desired := position + position.direction_to(point) * travel
		var actual_travel := position.distance_to(desired)
		position = desired
		remaining_distance -= actual_travel
		print("iteration=", iteration, " actual=", actual_travel, " remaining=", remaining_distance, " blocked_guard=", actual_travel + 0.01 < travel, " reached=", travel >= distance - 0.01)
		if remaining_distance <= 0.0:
			break
	quit()
