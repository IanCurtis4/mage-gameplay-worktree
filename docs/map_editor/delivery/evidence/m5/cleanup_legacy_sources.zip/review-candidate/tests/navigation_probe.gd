extends SceneTree

func _initialize() -> void:
	var nav := ArenaNavigation.new()
	nav.configure(RunController.ARENA_BOUNDS, RunController.ARENA_OBSTACLES, 22.0)
	var rng := RandomNumberGenerator.new()
	rng.seed = 914
	var invalid_segments := 0
	var checked := 0
	for sample in range(3000):
		var start := Vector2(rng.randf_range(102, 1698), rng.randf_range(102, 978))
		var finish := Vector2(rng.randf_range(102, 1698), rng.randf_range(102, 978))
		if not nav.is_walkable(start) or not nav.is_walkable(finish):
			continue
		var path := nav.get_path(start, finish)
		var previous := start
		for point in path:
			checked += 1
			var bad := false
			var steps := ceili(previous.distance_to(point) / 1.0)
			for step in range(1, steps + 1):
				if not nav.is_walkable(previous.lerp(point, float(step) / float(steps))):
					bad = true
					break
			if bad:
				invalid_segments += 1
				if invalid_segments < 4:
					print("Crosses obstacle: ", previous, " -> ", point)
			previous = point
	print("Sampled segments=", checked, " invalid=", invalid_segments)
	quit()
