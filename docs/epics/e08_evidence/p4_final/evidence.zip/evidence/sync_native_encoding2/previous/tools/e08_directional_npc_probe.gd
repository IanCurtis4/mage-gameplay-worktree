extends "res://tools/e08_directional_unit_probe.gd"
## Same renderer/cost scene; non-player samples never infer attachments.
var visual_id := ""
func run() -> void:
	var args := OS.get_cmdline_user_args()
	visual_id=args[2] if args.size()>2 else "warrior"
	if F.ORIGINS.has(StringName(visual_id)):
		await super.run();return
	folder=args[0];DirAccess.make_dir_recursive_absolute(folder);root.size=Vector2i(1280,720)
	unit_kind=&"animal_companion" if visual_id in ["e08_forest_wolf","e08_forest_boar"] else StringName(visual_id)
	require_default=args.has("--default")
	manifest="res://assets/art/%s/directional/%s/presentation.json" % ["animations" if require_default else "e08_enemies",visual_id]
	display_label=visual_id
	if args[1].begins_with("cost"):
		await cost(args[1]);return
	if args[1]=="motion":
		await motion();return
	var loaded := DirectionalAnimationSet.load_manifest(manifest)
	check(loaded.ok,"NPC complete manifest validates")
	if not loaded.ok:print(loaded);quit(1);return
	clear_page(visual_id+" · NPC sem anexos ·64poses ·S/N/E/W")
	for direction: int in 4:
		for pose: int in 16:actor(direction,pose,{},Vector2(70+pose*76,150+direction*165))
	await shot("01_body_64")
	for direction: int in 4:
		clear_page(visual_id+" · calibração ·"+["sul","norte","leste","oeste"][direction])
		for pose: int in 16:actor(direction,pose,{},Vector2(150+(pose%8)*136,290+(pose/8)*290),2.0,true)
		await shot("calibration_"+str(direction))
	clear_page(visual_id+" · mundo/câmera ·UI120")
	var camera := Camera2D.new();camera.position=Vector2(640,360);page.add_child(camera);camera.make_current()
	overlay.scale=Vector2.ONE*1.2
	for direction: int in 4:actor(direction,9,{},Vector2(450+direction*125,410))
	for zoom: float in [0.5,1.0,1.6]:
		camera.zoom=Vector2.ONE*zoom;camera.force_update_scroll();await shot("camera_"+str(int(zoom*100)))
	write_json("result.json",{"checks":checks,"failures":failures,"captures":captures,"visual_id":visual_id,"body_kind":unit_kind,"binding":"default" if require_default else "stage","scope":"real native renderer64poses; NPC no inferred equipment; no mapFPS claim"})
	print("E08 NPC native: %d checks, %d captures, %d failures" % [checks,captures.size(),failures]);quit(1 if failures else 0)
func cost_visual() -> Dictionary:
	return super.cost_visual() if F.ORIGINS.has(unit_kind) else {}
func configure_cost_override(animation: CharacterAnimation,mode: String) -> void:
	if mode=="cost_control" and visual_id in ["e08_forest_wolf","e08_forest_boar"]:
		check(animation.set_body_atlas(load("res://assets/art/animations/%s.png" % visual_id) as Texture2D),"specific NPC V1 control")
func bind_animation(animation: CharacterAnimation,label: String) -> void:
	if F.ORIGINS.has(unit_kind):super.bind_animation(animation,label);return
	check(animation.actor_kind==unit_kind,label+" body kind")
	check(animation.set_directional_manifest(manifest).ok,label+" specific NPC complete binding")
	check(animation.equipment_visual.is_empty(),"unadorned NPC")
